namespace Com.SharpZebra.Printing
{
    public interface IZebraPrinter
    {
        void Print(string rawData);
    }
}
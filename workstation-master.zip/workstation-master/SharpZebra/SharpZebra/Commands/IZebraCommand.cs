namespace Com.SharpZebra
{
    public interface IZebraCommand
    {
        string ToZebraInstruction();
    }
}
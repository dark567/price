ThermalLabel SDK for .NET
by Neodynamic SRL
http://www.neodynamic.com

README
==========================

Thank you for your interest in ThermalLabel SDK for .NET!


[*] Getting Started

     [*] Download Sample Code for Windows Forms at 		
         https://www.nuget.org/packages?q=neodynamic
 
     [*] Online Documentation
         We encourage you to read and download the ThermalLabel SDK for .NET
         help docs from http://www.neodynamic.com/get-help/

     [*] Try the Visual Label Editor Add-on and empower your own apps with
         an end-user visual designer for Windows Forms and WPF projects.
         Download sample code for Windows Forms at 
         https://www.nuget.org/packages?q=neodynamic
         NOTE: WPF samples are available with the full installer available at
         http://www.neodynamic.com	

[*] Do you need assistance?
Please feel free to ask us any questions or make any comments. 
Just contact us at support@neodynamic.com or 
http://www.neodynamic.com/Support


Thank you again for considering Neodynamic for your development needs. 
We look forward to working with you.
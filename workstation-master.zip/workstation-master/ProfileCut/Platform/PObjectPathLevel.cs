﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Platform
{
    //public class PObjectLevelPath
    //{
    //    public string CollectionName { set; get; }
    //    public int Index { set; get; }
    //}
}

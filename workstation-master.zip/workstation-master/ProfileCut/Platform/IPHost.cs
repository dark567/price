﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Platform
{
    public interface IPHost
    {
        string QueryToHost(string text);
    }
}

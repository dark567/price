﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleZebraPrinter
{
    public class MFont
    {
        public string Name { set; get; }
        public int Height { set; get; }
        public int Width { set; get; }
    }
}

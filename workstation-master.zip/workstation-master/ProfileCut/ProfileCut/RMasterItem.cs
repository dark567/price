﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//using Api;
using Platform2;

namespace ProfileCut
{
    public class RMasterItem
    {
        public string Title { set; get; }
        public IPObject Object { set; get; }
    }
}
